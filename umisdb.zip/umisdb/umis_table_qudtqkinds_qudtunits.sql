
-- --------------------------------------------------------

--
-- Table structure for table `qudtqkinds_qudtunits`
--

CREATE TABLE `qudtqkinds_qudtunits` (
  `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL,
  `qudtqkind_id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `qudtunit_id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='Join table for qudt units a qkinds';
