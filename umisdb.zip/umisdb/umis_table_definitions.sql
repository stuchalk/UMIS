
-- --------------------------------------------------------

--
-- Table structure for table `definitions`
--

CREATE TABLE `definitions` (
  `id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `quantitykind_id` smallint(5) UNSIGNED ZEROFILL DEFAULT NULL,
  `source_id` tinyint(3) UNSIGNED ZEROFILL NOT NULL,
  `definition` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `identifier` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `discipline` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `updates` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of definitions of units';
