
-- --------------------------------------------------------

--
-- Table structure for table `repsystems_usecases`
--

CREATE TABLE `repsystems_usecases` (
  `id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `repsystem_id` tinyint(3) UNSIGNED ZEROFILL NOT NULL,
  `usecase_id` tinyint(3) UNSIGNED ZEROFILL NOT NULL,
  `unit_id` mediumint(6) UNSIGNED ZEROFILL NOT NULL,
  `representation_id` mediumint(6) UNSIGNED ZEROFILL NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='Table linking repsystesms, usecase, and units';
