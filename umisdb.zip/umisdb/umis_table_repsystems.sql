
-- --------------------------------------------------------

--
-- Table structure for table `repsystems`
--

CREATE TABLE `repsystems` (
  `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `abbrev` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `version` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` enum('ontology','vocabulary','specification','guidelines','symbol','encoding') COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` enum('current','legacy') COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `repository` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `domain_id` tinyint(3) UNSIGNED ZEROFILL DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of unit representation systems';
