
-- --------------------------------------------------------

--
-- Table structure for table `prefixes`
--

CREATE TABLE `prefixes` (
  `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL,
  `name` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `symbol` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `inverse` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quantitysystem_id` tinyint(3) UNSIGNED ZEROFILL DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of prefixes for a quantity system';
