
-- --------------------------------------------------------

--
-- Table structure for table `dimensionvectors`
--

CREATE TABLE `dimensionvectors` (
  `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL,
  `name` varchar(2048) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `dim_exp_L` decimal(2,1) NOT NULL,
  `dim_exp_M` decimal(2,1) NOT NULL,
  `dim_exp_T` decimal(2,1) NOT NULL,
  `dim_exp_I` decimal(2,1) NOT NULL,
  `dim_exp_H` decimal(2,1) NOT NULL,
  `dim_exp_N` decimal(2,1) NOT NULL,
  `dim_exp_J` decimal(2,1) NOT NULL,
  `dim_exp_D` decimal(2,1) NOT NULL,
  `shortcode` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `longcode` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `symbol` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `basesi_shortcode` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `basesi_longcode` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quantitysystem_id` tinyint(3) UNSIGNED ZEROFILL NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of dimension vectors';
