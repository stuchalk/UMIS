
-- --------------------------------------------------------

--
-- Table structure for table `unitsystems`
--

CREATE TABLE `unitsystems` (
  `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(1024) COLLATE utf8_unicode_ci NOT NULL,
  `abbrev` varchar(16) COLLATE utf8_unicode_ci NOT NULL,
  `quantitysystem_id` tinyint(3) UNSIGNED ZEROFILL DEFAULT NULL,
  `url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of systems of quanitites (e.g. SI)';
