
--
-- Indexes for dumped tables
--

--
-- Indexes for table `constants`
--
ALTER TABLE `constants`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `correspondents`
--
ALTER TABLE `correspondents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dbpedia`
--
ALTER TABLE `dbpedia`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `definitions`
--
ALTER TABLE `definitions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dimensions`
--
ALTER TABLE `dimensions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `dimensionvectors`
--
ALTER TABLE `dimensionvectors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `domains`
--
ALTER TABLE `domains`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `encodings`
--
ALTER TABLE `encodings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `encodings_formats`
--
ALTER TABLE `encodings_formats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `equivalents`
--
ALTER TABLE `equivalents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `factors`
--
ALTER TABLE `factors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `formats`
--
ALTER TABLE `formats`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `iecs`
--
ALTER TABLE `iecs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nerc`
--
ALTER TABLE `nerc`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nyms`
--
ALTER TABLE `nyms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `prefixes`
--
ALTER TABLE `prefixes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quantities`
--
ALTER TABLE `quantities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quantitykinds`
--
ALTER TABLE `quantitykinds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quantitysystems`
--
ALTER TABLE `quantitysystems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qudtqkinds`
--
ALTER TABLE `qudtqkinds`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qudtqkinds.bak`
--
ALTER TABLE `qudtqkinds.bak`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qudtqkinds_qudtunits`
--
ALTER TABLE `qudtqkinds_qudtunits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qudtqkinds_qudtunits.bak`
--
ALTER TABLE `qudtqkinds_qudtunits.bak`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qudtunits`
--
ALTER TABLE `qudtunits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `qudtunits.bak`
--
ALTER TABLE `qudtunits.bak`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `representations`
--
ALTER TABLE `representations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Unit_Rep_Str` (`unit_id`,`repsystem_id`,`strng_id`);

--
-- Indexes for table `repsystems`
--
ALTER TABLE `repsystems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `repsystems_usecases`
--
ALTER TABLE `repsystems_usecases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sources`
--
ALTER TABLE `sources`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `strngs`
--
ALTER TABLE `strngs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ucum`
--
ALTER TABLE `ucum`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `udunits`
--
ALTER TABLE `udunits`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unece`
--
ALTER TABLE `unece`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unitsystems`
--
ALTER TABLE `unitsystems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usecases`
--
ALTER TABLE `usecases`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `versions`
--
ALTER TABLE `versions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `wikidata`
--
ALTER TABLE `wikidata`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `constants`
--
ALTER TABLE `constants`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `correspondents`
--
ALTER TABLE `correspondents`
  MODIFY `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dbpedia`
--
ALTER TABLE `dbpedia`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `definitions`
--
ALTER TABLE `definitions`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dimensions`
--
ALTER TABLE `dimensions`
  MODIFY `id` smallint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dimensionvectors`
--
ALTER TABLE `dimensionvectors`
  MODIFY `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `domains`
--
ALTER TABLE `domains`
  MODIFY `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `encodings`
--
ALTER TABLE `encodings`
  MODIFY `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `encodings_formats`
--
ALTER TABLE `encodings_formats`
  MODIFY `id` mediumint(8) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `equivalents`
--
ALTER TABLE `equivalents`
  MODIFY `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `factors`
--
ALTER TABLE `factors`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `formats`
--
ALTER TABLE `formats`
  MODIFY `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `iecs`
--
ALTER TABLE `iecs`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nerc`
--
ALTER TABLE `nerc`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `nyms`
--
ALTER TABLE `nyms`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `prefixes`
--
ALTER TABLE `prefixes`
  MODIFY `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quantities`
--
ALTER TABLE `quantities`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quantitykinds`
--
ALTER TABLE `quantitykinds`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `quantitysystems`
--
ALTER TABLE `quantitysystems`
  MODIFY `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `qudtqkinds`
--
ALTER TABLE `qudtqkinds`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `qudtqkinds.bak`
--
ALTER TABLE `qudtqkinds.bak`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `qudtqkinds_qudtunits`
--
ALTER TABLE `qudtqkinds_qudtunits`
  MODIFY `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `qudtqkinds_qudtunits.bak`
--
ALTER TABLE `qudtqkinds_qudtunits.bak`
  MODIFY `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `qudtunits`
--
ALTER TABLE `qudtunits`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `qudtunits.bak`
--
ALTER TABLE `qudtunits.bak`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `representations`
--
ALTER TABLE `representations`
  MODIFY `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `repsystems`
--
ALTER TABLE `repsystems`
  MODIFY `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `repsystems_usecases`
--
ALTER TABLE `repsystems_usecases`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sources`
--
ALTER TABLE `sources`
  MODIFY `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `strngs`
--
ALTER TABLE `strngs`
  MODIFY `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ucum`
--
ALTER TABLE `ucum`
  MODIFY `id` smallint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `udunits`
--
ALTER TABLE `udunits`
  MODIFY `id` smallint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `unece`
--
ALTER TABLE `unece`
  MODIFY `id` smallint(4) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `unitsystems`
--
ALTER TABLE `unitsystems`
  MODIFY `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `usecases`
--
ALTER TABLE `usecases`
  MODIFY `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `versions`
--
ALTER TABLE `versions`
  MODIFY `id` smallint(3) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `wikidata`
--
ALTER TABLE `wikidata`
  MODIFY `id` smallint(5) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT;
