
-- --------------------------------------------------------

--
-- Table structure for table `encodings_formats`
--

CREATE TABLE `encodings_formats` (
  `id` mediumint(8) UNSIGNED ZEROFILL NOT NULL,
  `format_id` tinyint(3) UNSIGNED ZEROFILL NOT NULL,
  `encoding_id` smallint(6) UNSIGNED ZEROFILL NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Join table between formats and encodings (or strings)';
