
-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `quantitykind_id` smallint(5) UNSIGNED ZEROFILL DEFAULT NULL,
  `unitsystem_id` tinyint(3) UNSIGNED ZEROFILL DEFAULT NULL,
  `description` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `prefix_id` tinyint(3) UNSIGNED ZEROFILL DEFAULT NULL,
  `factor_id` smallint(5) UNSIGNED ZEROFILL DEFAULT NULL,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` enum('Accepted Non-SI','CGS Base','Other','SI Base','SI Coherent Derived','SI Derived','US Customary') COLLATE utf8_unicode_ci DEFAULT NULL,
  `shortcode` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `alt_shortcode` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ivoa` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `html` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `text_SI` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of units';
