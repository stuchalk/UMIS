
-- --------------------------------------------------------

--
-- Table structure for table `dimensions`
--

CREATE TABLE `dimensions` (
  `id` smallint(3) UNSIGNED ZEROFILL NOT NULL,
  `quantitysystem_id` smallint(3) UNSIGNED ZEROFILL NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `symbol` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `qudtstring` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of dimensions (e.g. length)';
