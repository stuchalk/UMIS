
-- --------------------------------------------------------

--
-- Table structure for table `usecases`
--

CREATE TABLE `usecases` (
  `id` tinyint(3) UNSIGNED ZEROFILL NOT NULL,
  `name` varchar(64) COLLATE utf8mb4_bin NOT NULL,
  `description` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='Table of unit use cases';
