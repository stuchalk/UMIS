
-- --------------------------------------------------------

--
-- Table structure for table `encodings`
--

CREATE TABLE `encodings` (
  `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL,
  `strng_id` mediumint(6) UNSIGNED ZEROFILL DEFAULT NULL,
  `string` varchar(512) COLLATE utf8_unicode_ci NOT NULL,
  `format` enum('ascii','utf8','latex','silatex','html','ivoa','siunitx') COLLATE utf8_unicode_ci NOT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of unit representation strings';
