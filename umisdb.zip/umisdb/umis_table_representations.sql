
-- --------------------------------------------------------

--
-- Table structure for table `representations`
--

CREATE TABLE `representations` (
  `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL,
  `unit_id` mediumint(6) UNSIGNED ZEROFILL DEFAULT NULL,
  `quantity_id` smallint(5) UNSIGNED ZEROFILL DEFAULT NULL,
  `unitsystem_id` tinyint(3) UNSIGNED ZEROFILL DEFAULT NULL,
  `repsystem_id` tinyint(3) UNSIGNED ZEROFILL DEFAULT NULL,
  `strng_id` mediumint(6) UNSIGNED ZEROFILL NOT NULL,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of unit representations';
