
-- --------------------------------------------------------

--
-- Table structure for table `equivalents`
--

CREATE TABLE `equivalents` (
  `id` mediumint(6) UNSIGNED ZEROFILL NOT NULL,
  `from_unit` mediumint(6) UNSIGNED ZEROFILL NOT NULL,
  `to_unit` mediumint(6) UNSIGNED ZEROFILL NOT NULL,
  `factor` float DEFAULT NULL,
  `prefix_id` tinyint(3) UNSIGNED ZEROFILL DEFAULT NULL,
  `constant_id` smallint(4) UNSIGNED DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of unit equivalents';
