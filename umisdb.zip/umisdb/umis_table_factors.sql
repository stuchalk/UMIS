
-- --------------------------------------------------------

--
-- Table structure for table `factors`
--

CREATE TABLE `factors` (
  `id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_bin NOT NULL,
  `nunit_id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `dunit_id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `nfactor` varchar(16) COLLATE utf8mb4_bin NOT NULL,
  `dfactor` varchar(16) COLLATE utf8mb4_bin NOT NULL,
  `exact` enum('yes','no') COLLATE utf8mb4_bin NOT NULL DEFAULT 'no',
  `sf` tinyint(1) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='Table of conversion factors';
