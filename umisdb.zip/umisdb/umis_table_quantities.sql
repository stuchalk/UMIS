
-- --------------------------------------------------------

--
-- Table structure for table `quantities`
--

CREATE TABLE `quantities` (
  `id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `quantitykind_id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `quantitysystem_id` tinyint(3) UNSIGNED ZEROFILL DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `symbol` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latexsymbol` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `latexdefn` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `domain_id` tinyint(3) UNSIGNED ZEROFILL DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of quantity kinds (e.g. length)';
