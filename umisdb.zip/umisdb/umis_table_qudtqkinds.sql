
-- --------------------------------------------------------

--
-- Table structure for table `qudtqkinds`
--

CREATE TABLE `qudtqkinds` (
  `id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `code` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `description` varchar(2048) COLLATE utf8mb4_bin DEFAULT NULL,
  `dimvector` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `ddimvector` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `ndimvector` varchar(64) COLLATE utf8mb4_bin DEFAULT NULL,
  `dims` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL,
  `basedims` varchar(256) COLLATE utf8mb4_bin DEFAULT NULL,
  `basecgsdims` varchar(256) COLLATE utf8mb4_bin DEFAULT NULL,
  `baseimpdims` varchar(256) COLLATE utf8mb4_bin DEFAULT NULL,
  `baseisodims` varchar(256) COLLATE utf8mb4_bin DEFAULT NULL,
  `basesidims` varchar(256) COLLATE utf8mb4_bin DEFAULT NULL,
  `baseusdims` varchar(256) COLLATE utf8mb4_bin DEFAULT NULL,
  `labels` varchar(256) COLLATE utf8mb4_bin DEFAULT NULL,
  `altlabels` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL,
  `latexdefn` varchar(1024) COLLATE utf8mb4_bin DEFAULT NULL,
  `latexsymb` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `symbols` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL,
  `nrefs` varchar(1024) COLLATE utf8mb4_bin DEFAULT NULL,
  `infrefs` varchar(1024) COLLATE utf8mb4_bin DEFAULT NULL,
  `isorefs` varchar(1024) COLLATE utf8mb4_bin DEFAULT NULL,
  `matches` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL,
  `cmatches` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL,
  `urls` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL,
  `siunits` varchar(256) COLLATE utf8mb4_bin DEFAULT NULL,
  `broader` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL,
  `sameas` varchar(1024) COLLATE utf8mb4_bin DEFAULT NULL,
  `seealso` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL,
  `comesfrom` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL,
  `abbrevs` varchar(512) COLLATE utf8mb4_bin DEFAULT NULL,
  `comments` varchar(1024) COLLATE utf8mb4_bin DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='Table of QUDT unit entries';
