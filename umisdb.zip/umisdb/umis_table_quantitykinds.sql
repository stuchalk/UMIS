
-- --------------------------------------------------------

--
-- Table structure for table `quantitykinds`
--

CREATE TABLE `quantitykinds` (
  `id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `type` enum('base','derived','coherent derived','special name','accepted','cgs','cgs special') COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `symbol` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `shortcode` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `baseunit_id` mediumint(6) UNSIGNED ZEROFILL DEFAULT NULL,
  `quantitysystem_id` tinyint(3) UNSIGNED ZEROFILL NOT NULL,
  `dimensionvector_id` smallint(6) UNSIGNED ZEROFILL DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of quantitykinds';
