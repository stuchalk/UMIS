
-- --------------------------------------------------------

--
-- Table structure for table `constants`
--

CREATE TABLE `constants` (
  `id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `shortname` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(1024) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `stduncertainty` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `relstduncertainty` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `version` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `symbol` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `concise_html` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `concise_text` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mantissa` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `exponent` tinyint(2) DEFAULT NULL,
  `sigfigs` tinyint(1) DEFAULT NULL,
  `dps` tinyint(1) DEFAULT NULL,
  `exact` enum('yes','no') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'no',
  `quantity_id` smallint(5) UNSIGNED ZEROFILL DEFAULT NULL,
  `unit_id` mediumint(6) UNSIGNED ZEROFILL DEFAULT NULL,
  `url` varchar(512) COLLATE utf8_unicode_ci DEFAULT NULL,
  `validfrom` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unitstr` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unitstrsi` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of physical and other constants';
