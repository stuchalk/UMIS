
-- --------------------------------------------------------

--
-- Table structure for table `nyms`
--

CREATE TABLE `nyms` (
  `id` smallint(5) UNSIGNED ZEROFILL NOT NULL,
  `quantity_id` smallint(5) UNSIGNED ZEROFILL DEFAULT NULL,
  `quantitykind_id` smallint(5) UNSIGNED ZEROFILL DEFAULT NULL,
  `unit_id` mediumint(6) UNSIGNED ZEROFILL DEFAULT NULL,
  `value` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `domain_id` tinyint(3) UNSIGNED ZEROFILL DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Table of nyms - acronyms etc';
