/* Extra global constants for the unity library (all internal-only) */

/* This char indicates the prefix 'da' */
#define UNITY_PREFIX_DECA 1

/* Similar ones for kibi- etc? */
