/*
 * This is a GENERATED FILE -- do not edit.
 * See known-units.csv and buildtools/src/ParseUnits.java.
 */


/**
 * @file unity.h
 */

#include <stdio.h>              /* for NULL */
#include <stdlib.h>             /* for bsearch */
#include <string.h>             /* for strcmp */
#include <assert.h>

#define UNITY_INTERNAL 1
#include "unit-definitions.h"
#include "known-syntaxes.h"

static const char* known_syntaxes[] = { "fits", "ogip", "cds", "vounits", };
/* List of all the known units */
static UnitDef unit_defs[] = {
  { "http://qudt.org/vocab/unit#Henry", 0,
    "Henry",
    "http://qudt.org/vocab/quantity#Inductance",
    "L ",
    NULL,
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#SolarMass", 1,
    "Solar mass",
    "http://qudt.org/vocab/quantity#Mass",
    "M ",
    "The mass of the sun is 1.9891e30 kg",
    "M\\solar" },
  { "http://qudt.org/vocab/unit#Parsec", 2,
    "Parsec",
    "http://qudt.org/vocab/quantity#Length",
    "L ",
    "The parsec (parallax of one arcsecond; symbol: pc) is a unit of length, equal to just under 31 trillion (31×1012) kilometres (about 19 trillion miles), 206265 AU, or about 3.26 light-years. The parsec measurement unit is used in astronomy. It is defined as the length of the adjacent side of an imaginary right triangle in space. The two dimensions that specify this triangle are the parallax angle (defined as 1 arcsecond) and the opposite side (defined as 1 astronomical unit (AU), the distance from the Earth to the Sun). Given these two measurements, along with the rules of trigonometry, the length of the adjacent side (the parsec) can be found. [Wikipedia]",
    NULL },
  { "http://qudt.org/vocab/unit#Siemens", 3,
    "Siemens",
    "http://qudt.org/vocab/quantity#ElectricConductivity",
    "L^-1 T ",
    NULL,
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#Pixel", 4,
    "pixel",
    "http://qudt.org/vocab/quantity#Dimensionless",
    "U ",
    "an element of a 2-D image",
    NULL },
  { "http://qudt.org/vocab/unit#AstronomicalUnit", 5,
    "Astronomical Unit",
    "http://qudt.org/vocab/quantity#Length",
    "L ",
    NULL,
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#SolarRadius", 6,
    "solRad",
    "http://qudt.org/vocab/quantity#Length",
    "L ",
    "6.9599e8 m",
    "R\\solar" },
  { "http://qudt.org/vocab/unit#ElectronVolt", 7,
    "Electron Volt",
    "http://qudt.org/vocab/quantity#EnergyAndWork",
    "L^2 M T^-2 ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Farad", 8,
    "Farad",
    "http://qudt.org/vocab/quantity#Capacitance",
    "L^-1 T^2 ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#LightYear", 9,
    "Light Year",
    "http://qudt.org/vocab/quantity#Length",
    "L ",
    "A unit of length defining the distance, in meters, that light travels in a vacuum in one year.",
    NULL },
  { "http://qudt.org/vocab/unit#UnifiedAtomicMassUnit", 10,
    "Unified Atomic Mass Unit",
    "http://qudt.org/vocab/quantity#Mass",
    "M ",
    NULL,
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#JulianCentury", 11,
    "Julian Century",
    "http://qudt.org/vocab/quantity#Time",
    "T ",
    "One hundred Julian Years",
    NULL },
  { "http://qudt.org/vocab/unit#Barn", 12,
    "Barn",
    "http://qudt.org/vocab/quantity#Area",
    "L^2 ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Volt", 13,
    "Volt",
    "http://qudt.org/vocab/quantity#EnergyPerElectricCharge",
    "L^1.5 M^0.5 T^-2 ",
    NULL,
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#Crab", 14,
    "Crab",
    "http://bitbucket/org/nxg/unity/ns/quantity#SpecificIntensity",
    "M T^-2 ",
    "The flux density, relative to that of the Crab.\nMentioned in the OGIP standard, but strongly disrecommended.\nThe OGIP standard permits only 'm' as a prefix.",
    NULL },
  { "http://qudt.org/vocab/unit#MinuteTime", 15,
    "Minute Time",
    "http://qudt.org/vocab/quantity#Time",
    "T ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#ArcMinute", 16,
    "Arc Minute",
    "http://qudt.org/vocab/quantity#PlaneAngle",
    "U ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Number", 17,
    "Number",
    "http://qudt.org/vocab/quantity#Dimensionless",
    "U ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#DegreeAngle", 18,
    "Degree Angle",
    "http://qudt.org/vocab/quantity#PlaneAngle",
    "U ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Day", 19,
    "Day",
    "http://qudt.org/vocab/quantity#Time",
    "T ",
    "Mean solar day",
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#Jansky", 20,
    "Jy",
    "http://bitbucket/org/nxg/unity/ns/quantity#SpecificIntensity",
    "M T^-2 ",
    "10^-26 W m-2 Hz-1",
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#Beam", 21,
    "beam",
    "http://qudt.org/vocab/quantity#Dimensionless",
    "U ",
    "as in Jy/beam",
    NULL },
  { "http://qudt.org/vocab/unit#Joule", 22,
    "Joule",
    "http://qudt.org/vocab/quantity#EnergyAndWork",
    "L^2 M T^-2 ",
    NULL,
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#Voxel", 23,
    "voxel",
    "http://qudt.org/vocab/quantity#Dimensionless",
    "U ",
    "The 3-D analogue of a pixel",
    NULL },
  { "http://qudt.org/vocab/unit#Newton", 24,
    "Newton",
    "http://qudt.org/vocab/quantity#Force",
    "L M T^-2 ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#ArcSecond", 25,
    "Arc Second",
    "http://qudt.org/vocab/quantity#PlaneAngle",
    "U ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Mole", 26,
    "Mole",
    "http://qudt.org/vocab/quantity#AmountOfSubstance",
    "N ",
    NULL,
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#Rydberg", 27,
    "Ry",
    "http://qudt.org/vocab/quantity#EnergyAndWork",
    "L^2 M T^-2 ",
    "Half of the Hartree energy, defined as 13.605692 eV.  See http://en.wikipedia.org/wiki/Hartree",
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#MilliArcSecond", 28,
    "mas",
    "http://qudt.org/vocab/quantity#PlaneAngle",
    "U ",
    "1/1000 of an arc-second, for use in those syntaxes which do not allow SI prefixes of arcsec",
    NULL },
  { "http://qudt.org/vocab/unit#Erg", 29,
    "Erg",
    "http://qudt.org/vocab/quantity#EnergyAndWork",
    "L^2 M T^-2 ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Percent", 30,
    "Percent",
    "http://qudt.org/vocab/quantity#DimensionlessRatio",
    "U ",
    NULL,
    "\\%" },
  { "http://bitbucket.org/nxg/unity/ns/unit#StellarMagnitude", 31,
    "mag",
    "http://bitbucket/org/nxg/unity/ns/quantity#StellarMagnitudeQuantityKind",
    "U ",
    "Log of a ratio of intensities.  See http://en.wikipedia.org/wiki/Magnitude_(astronomy)",
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#DetectorChannel", 32,
    "chan",
    "http://qudt.org/vocab/quantity#Dimensionless",
    "U ",
    "One channel in a detector of some type",
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#ADU", 33,
    "ADU",
    "http://qudt.org/vocab/quantity#Dimensionless",
    "U ",
    "Same as channel???",
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#Photon", 34,
    "ph",
    "http://qudt.org/vocab/quantity#Dimensionless",
    "U ",
    "as in ev/photon",
    NULL },
  { "http://qudt.org/vocab/unit#Radian", 35,
    "Radian",
    "http://qudt.org/vocab/quantity#PlaneAngle",
    "U ",
    "The radian is the standard unit of angular measure, used in many areas of mathematics. It describes the plane angle subtended by a circular arc as the length of the arc divided by the radius of the arc. The unit was formerly a SI supplementary unit, but this category was abolished in 1995 and the radian is now considered a SI derived unit. The SI unit of solid angle measurement is the steradian.\nThe radian is represented by the symbol \"rad\" or, more rarely, by the superscript c (for \"circular measure\"). For example, an angle of 1.2 radians would be written as \"1.2 rad\" or \"1.2c\" (the second symbol is often mistaken for a degree: \"1.2°\"). As the ratio of two lengths, the radian is a \"pure number\" that needs no unit symbol, and in mathematical writing the symbol \"rad\" is almost always omitted. In the absence of any symbol radians are assumed, and when degrees are meant the symbol ° is used. [Wikipedia]",
    NULL },
  { "http://qudt.org/vocab/unit#YearTropical", 36,
    "Year Tropical",
    "http://qudt.org/vocab/quantity#Time",
    "T ",
    NULL,
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#JulianYear", 37,
    "Julian year",
    "http://qudt.org/vocab/quantity#Time",
    "T ",
    "31 557 600s (365.25d), peta a (Pa) forbidden",
    NULL },
  { "http://qudt.org/vocab/unit#Hertz", 38,
    "Hertz",
    "http://qudt.org/vocab/quantity#Frequency",
    "T^-1 ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Watt", 39,
    "Watt",
    "http://qudt.org/vocab/quantity#HeatFlowRate",
    "L^2 M T^-3 ",
    NULL,
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#DistributionBin", 40,
    "bin",
    "http://qudt.org/vocab/quantity#Dimensionless",
    "U ",
    "One division within a distribution",
    NULL },
  { "http://qudt.org/vocab/unit#Ohm", 41,
    "Ohm",
    "http://qudt.org/vocab/quantity#Resistance",
    "L T^-1 ",
    NULL,
    "\\ohm" },
  { "http://qudt.org/vocab/unit#Candela", 42,
    "Candela",
    "http://qudt.org/vocab/quantity#LuminousIntensity",
    "J ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Angstrom", 43,
    "Angstrom",
    "http://qudt.org/vocab/quantity#Length",
    "L ",
    "The ångström or angstrom (symbol Å) (the latter spelling, without diacritics, is now usually used in English) (pronounced /ˈæŋstrəm/; Swedish: [ˈɔŋstrøm]) is an internationally recognized unit of length equal to 0.1 nanometre or 1×10−10 metres. It is named after Anders Jonas Ångström. Although accepted for use, it is not formally defined within the International System of Units(SI). (That article lists the units that are so defined.) The ångström is often used in the natural sciences to express the sizes of atoms, lengths of chemical bonds and the wavelengths of electromagnetic radiation, and in technology for the dimensions of parts of integrated circuits. It is also commonly used in structural biology. [Wikipedia]",
    "\\angstrom" },
  { "http://qudt.org/vocab/unit#Gauss", 44,
    "Gauss",
    "http://qudt.org/vocab/quantity#MagneticField",
    "L^-0.5 M^0.5 T^-1 ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Meter", 45,
    "Metre",
    "http://qudt.org/vocab/quantity#Length",
    "L ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Lumen", 46,
    "Lumen",
    "http://qudt.org/vocab/quantity#LuminousFlux",
    "U J ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Bit", 47,
    "Bit",
    "http://qudt.org/vocab/quantity#InformationEntropy",
    "U ",
    "In information theory, a bit is the amount of information that, on average, can be stored in a discrete bit. It is thus the amount of information carried by a choice between two equally likely outcomes. One bit corresponds to about 0.693 nats (ln(2)), or 0.301 hartleys (log10(2)).",
    "\\bit" },
  { "http://qudt.org/vocab/unit#Weber", 48,
    "Weber",
    "http://qudt.org/vocab/quantity#MagneticFlux",
    "L^1.5 M^0.5 T^-1 ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Kelvin", 49,
    "Kelvin",
    "http://qudt.org/vocab/quantity#ThermodynamicTemperature",
    "Θ ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Ampere", 50,
    "Ampere",
    "http://qudt.org/vocab/quantity#ElectricCurrent",
    "L^0.5 M^0.5 T^-1 ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Hour", 51,
    "Hour",
    "http://qudt.org/vocab/quantity#Time",
    "T ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Tesla", 52,
    "Tesla",
    "http://qudt.org/vocab/quantity#MagneticField",
    "L^-0.5 M^0.5 T^-1 ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Decibel", 53,
    "Decibel",
    "http://qudt.org/vocab/quantity#RF-Power",
    "L^0.5 M^0.5 T^-2 ",
    NULL,
    "\\decibel" },
  { "http://qudt.org/vocab/unit#Lux", 54,
    "Lux",
    "http://qudt.org/vocab/quantity#LuminousFluxPerArea",
    "U L^-2 J ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Steradian", 55,
    "Steradian",
    "http://qudt.org/vocab/quantity#SolidAngle",
    "U ",
    "The steradian (symbol: sr) is the SI unit of solid angle. It is used to describe two-dimensional angular spans in three-dimensional space, analogous to the way in which the radian describes angles in a plane.",
    NULL },
  { "http://qudt.org/vocab/unit#Debye", 56,
    "Debye",
    "http://qudt.org/vocab/quantity#ElectricDipoleMoment",
    "L T I ",
    NULL,
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#BesselianYear", 57,
    "Bessellian Year",
    "http://qudt.org/vocab/quantity#Time",
    "T ",
    "The Besselian year.\nSee the discussion in FITS WCS paper IV, section 4.2,\nfor important caveats concerning the use of the Besselian and Tropical years.\n",
    NULL },
  { "http://qudt.org/vocab/unit#SecondTime", 58,
    "Second",
    "http://qudt.org/vocab/quantity#Time",
    "T ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Gram", 59,
    "Gramme",
    "http://qudt.org/vocab/quantity#Mass",
    "M ",
    NULL,
    NULL },
  { "http://qudt.org/vocab/unit#Coulomb", 60,
    "Coulomb",
    "http://qudt.org/vocab/quantity#ElectricCharge",
    "L^0.5 M^0.5 ",
    NULL,
    NULL },
  { "http://bitbucket.org/nxg/unity/ns/unit#Rayleigh", 61,
    "R",
    "http://bitbucket.org/nxg/unity/ns/unit#PhotonFlux",
    "L^-2 T-2",
    "Unit of photon flux density: Wikipedia has units of 10^10 photons/m2/column/s.\nThe FITS spec has units of 1e10/(4PI) photons m-2 s-2 sr-1.\nSee http://en.wikipedia.org/wiki/Rayleigh_(unit).\nNo, I don't know how to express its dimensions in the QUDT system!\nWe go with the FITS definition here.",
    NULL },
  { "http://qudt.org/vocab/unit#Byte", 62,
    "Byte",
    "http://qudt.org/vocab/quantity#InformationEntropy",
    "U ",
    NULL,
    "\\byte" },
  { "http://bitbucket.org/nxg/unity/ns/unit#SolarLuminosity", 63,
    "solLum",
    "http://qudt.org/vocab/quantity#Power",
    "L^2 M T^-3 ",
    "3.8268e26 W",
    "L\\solar" },
  { "http://qudt.org/vocab/unit#Pascal", 64,
    "Pascal",
    "http://qudt.org/vocab/quantity#ForcePerArea",
    "L^-1 M T^-2 ",
    NULL,
    NULL },
};
static int unit_defs_length = 65;


// Reverse lookups, per-syntax maps going from symbols to UnitDefinitions

/* A lookup table, mapping symbols to an index in the unit_representation array above.
 * There are three arrays in here, separatedly ordered by symbol,
 * with the start offsets indicated by the unit_rep_per_syntax array below.
 */
static struct unit_representation unit_reps[] = {

  // unit representations for syntax fits
  { "A", 50, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Ampere
  { "AU", 5, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#AstronomicalUnit
  { "Angstrom", 43, 0, 0, 1, 0 }, // http://qudt.org/vocab/unit#Angstrom
  { "Ba", 57, 0, 0, 1, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#BesselianYear
  { "C", 60, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Coulomb
  { "D", 56, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Debye
  { "F", 8, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Farad
  { "G", 44, 1, 0, 1, 0 }, // http://qudt.org/vocab/unit#Gauss
  { "H", 0, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Henry
  { "Hz", 38, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Hertz
  { "J", 22, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Joule
  { "Jy", 20, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Jansky
  { "K", 49, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Kelvin
  { "N", 24, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Newton
  { "Ohm", 41, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Ohm
  { "Pa", 64, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Pascal
  { "R", 61, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Rayleigh
  { "Ry", 27, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Rydberg
  { "S", 3, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Siemens
  { "T", 52, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Tesla
  { "V", 13, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Volt
  { "W", 39, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Watt
  { "Wb", 48, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Weber
  { "a", 37, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#JulianYear
  { "adu", 33, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#ADU
  { "arcmin", 16, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#ArcMinute
  { "arcsec", 25, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#ArcSecond
  { "barn", 12, 1, 0, 1, 0 }, // http://qudt.org/vocab/unit#Barn
  { "beam", 21, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Beam
  { "bin", 40, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#DistributionBin
  { "bit", 47, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Bit
  { "byte", 62, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Byte
  { "cd", 42, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Candela
  { "chan", 32, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#DetectorChannel
  { "count", 17, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Number
  { "ct", 17, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Number
  { "cy", 11, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#JulianCentury
  { "d", 19, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Day
  { "deg", 18, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#DegreeAngle
  { "eV", 7, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#ElectronVolt
  { "erg", 29, 0, 0, 1, 0 }, // http://qudt.org/vocab/unit#Erg
  { "g", 59, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Gram
  { "h", 51, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Hour
  { "lm", 46, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Lumen
  { "lx", 54, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Lux
  { "lyr", 9, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#LightYear
  { "m", 45, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Meter
  { "mag", 31, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#StellarMagnitude
  { "mas", 28, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#MilliArcSecond
  { "min", 15, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#MinuteTime
  { "mol", 26, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Mole
  { "pc", 2, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Parsec
  { "ph", 34, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Photon
  { "photon", 34, 0, 0, 0, 1 }, // http://bitbucket.org/nxg/unity/ns/unit#Photon
  { "pix", 4, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Pixel
  { "pixel", 4, 0, 0, 0, 1 }, // http://bitbucket.org/nxg/unity/ns/unit#Pixel
  { "rad", 35, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Radian
  { "s", 58, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#SecondTime
  { "solLum", 63, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#SolarLuminosity
  { "solMass", 1, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#SolarMass
  { "solRad", 6, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#SolarRadius
  { "sr", 55, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Steradian
  { "ta", 36, 0, 0, 1, 0 }, // http://qudt.org/vocab/unit#YearTropical
  { "u", 10, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#UnifiedAtomicMassUnit
  { "voxel", 23, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Voxel
  { "yr", 37, 1, 0, 0, 1 }, // http://bitbucket.org/nxg/unity/ns/unit#JulianYear

  // unit representations for syntax ogip
  { "A", 50, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Ampere
  { "AU", 5, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#AstronomicalUnit
  { "C", 60, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Coulomb
  { "Crab", 14, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Crab
  { "F", 8, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Farad
  { "G", 44, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Gauss
  { "H", 0, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Henry
  { "Hz", 38, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Hertz
  { "J", 22, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Joule
  { "Jy", 20, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Jansky
  { "K", 49, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Kelvin
  { "N", 24, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Newton
  { "Pa", 64, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Pascal
  { "S", 3, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Siemens
  { "T", 52, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Tesla
  { "V", 13, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Volt
  { "W", 39, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Watt
  { "Wb", 48, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Weber
  { "angstrom", 43, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Angstrom
  { "arcmin", 16, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#ArcMinute
  { "arcsec", 25, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#ArcSecond
  { "barn", 12, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Barn
  { "bin", 40, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#DistributionBin
  { "byte", 62, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Byte
  { "cd", 42, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Candela
  { "chan", 32, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#DetectorChannel
  { "count", 17, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Number
  { "d", 19, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Day
  { "deg", 18, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#DegreeAngle
  { "eV", 7, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#ElectronVolt
  { "erg", 29, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Erg
  { "g", 59, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Gram
  { "h", 51, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Hour
  { "lm", 46, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Lumen
  { "lx", 54, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Lux
  { "lyr", 9, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#LightYear
  { "m", 45, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Meter
  { "mag", 31, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#StellarMagnitude
  { "min", 15, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#MinuteTime
  { "mol", 26, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Mole
  { "ohm", 41, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Ohm
  { "pc", 2, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Parsec
  { "photon", 34, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Photon
  { "pixel", 4, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Pixel
  { "rad", 35, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Radian
  { "s", 58, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#SecondTime
  { "sr", 55, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Steradian
  { "voxel", 23, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Voxel
  { "yr", 37, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#JulianYear

  // unit representations for syntax cds
  { "%", 30, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Percent
  { "A", 50, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Ampere
  { "AU", 5, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#AstronomicalUnit
  { "Angstrom", 43, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Angstrom
  { "C", 60, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Coulomb
  { "D", 56, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Debye
  { "F", 8, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Farad
  { "H", 0, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Henry
  { "Hz", 38, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Hertz
  { "J", 22, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Joule
  { "Jy", 20, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Jansky
  { "K", 49, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Kelvin
  { "N", 24, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Newton
  { "Ohm", 41, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Ohm
  { "Pa", 64, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Pascal
  { "Ry", 27, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Rydberg
  { "S", 3, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Siemens
  { "T", 52, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Tesla
  { "V", 13, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Volt
  { "W", 39, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Watt
  { "Wb", 48, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Weber
  { "a", 37, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#JulianYear
  { "arcmin", 16, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#ArcMinute
  { "arcsec", 25, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#ArcSecond
  { "barn", 12, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Barn
  { "bit", 47, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Bit
  { "byte", 62, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Byte
  { "cd", 42, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Candela
  { "ct", 17, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Number
  { "d", 19, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Day
  { "deg", 18, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#DegreeAngle
  { "eV", 7, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#ElectronVolt
  { "g", 59, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Gram
  { "h", 51, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Hour
  { "lm", 46, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Lumen
  { "lx", 54, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Lux
  { "m", 45, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Meter
  { "mag", 31, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#StellarMagnitude
  { "mas", 28, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#MilliArcSecond
  { "min", 15, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#MinuteTime
  { "mol", 26, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Mole
  { "pc", 2, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Parsec
  { "pix", 4, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Pixel
  { "rad", 35, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Radian
  { "s", 58, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#SecondTime
  { "solLum", 63, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#SolarLuminosity
  { "solMass", 1, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#SolarMass
  { "solRad", 6, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#SolarRadius
  { "sr", 55, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Steradian
  { "yr", 37, 1, 0, 0, 1 }, // http://bitbucket.org/nxg/unity/ns/unit#JulianYear

  // unit representations for syntax vounits
  { "A", 50, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Ampere
  { "AU", 5, 0, 0, 0, 1 }, // http://qudt.org/vocab/unit#AstronomicalUnit
  { "Angstrom", 43, 0, 0, 1, 1 }, // http://qudt.org/vocab/unit#Angstrom
  { "B", 62, 1, 1, 0, 0 }, // http://qudt.org/vocab/unit#Byte
  { "Ba", 57, 0, 0, 1, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#BesselianYear
  { "C", 60, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Coulomb
  { "D", 56, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Debye
  { "F", 8, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Farad
  { "G", 44, 1, 0, 1, 0 }, // http://qudt.org/vocab/unit#Gauss
  { "H", 0, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Henry
  { "Hz", 38, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Hertz
  { "J", 22, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Joule
  { "Jy", 20, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Jansky
  { "K", 49, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Kelvin
  { "N", 24, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Newton
  { "Ohm", 41, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Ohm
  { "Pa", 64, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Pascal
  { "R", 61, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Rayleigh
  { "Ry", 27, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Rydberg
  { "S", 3, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Siemens
  { "T", 52, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Tesla
  { "V", 13, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Volt
  { "W", 39, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Watt
  { "Wb", 48, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Weber
  { "a", 37, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#JulianYear
  { "adu", 33, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#ADU
  { "angstrom", 43, 0, 0, 1, 0 }, // http://qudt.org/vocab/unit#Angstrom
  { "arcmin", 16, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#ArcMinute
  { "arcsec", 25, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#ArcSecond
  { "au", 5, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#AstronomicalUnit
  { "barn", 12, 1, 0, 1, 0 }, // http://qudt.org/vocab/unit#Barn
  { "beam", 21, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Beam
  { "bin", 40, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#DistributionBin
  { "bit", 47, 1, 1, 0, 0 }, // http://qudt.org/vocab/unit#Bit
  { "byte", 62, 1, 1, 0, 1 }, // http://qudt.org/vocab/unit#Byte
  { "cd", 42, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Candela
  { "chan", 32, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#DetectorChannel
  { "count", 17, 1, 0, 0, 1 }, // http://qudt.org/vocab/unit#Number
  { "ct", 17, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Number
  { "d", 19, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Day
  { "dB", 53, 0, 0, 0, 0 }, // http://qudt.org/vocab/unit#Decibel
  { "deg", 18, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#DegreeAngle
  { "eV", 7, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#ElectronVolt
  { "erg", 29, 1, 0, 1, 0 }, // http://qudt.org/vocab/unit#Erg
  { "g", 59, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Gram
  { "h", 51, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Hour
  { "lm", 46, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Lumen
  { "lx", 54, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Lux
  { "lyr", 9, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#LightYear
  { "m", 45, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Meter
  { "mag", 31, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#StellarMagnitude
  { "mas", 28, 0, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#MilliArcSecond
  { "min", 15, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#MinuteTime
  { "mol", 26, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Mole
  { "pc", 2, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Parsec
  { "ph", 34, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Photon
  { "photon", 34, 1, 0, 0, 1 }, // http://bitbucket.org/nxg/unity/ns/unit#Photon
  { "pix", 4, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Pixel
  { "pixel", 4, 1, 0, 0, 1 }, // http://bitbucket.org/nxg/unity/ns/unit#Pixel
  { "rad", 35, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Radian
  { "s", 58, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#SecondTime
  { "solLum", 63, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#SolarLuminosity
  { "solMass", 1, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#SolarMass
  { "solRad", 6, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#SolarRadius
  { "sr", 55, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#Steradian
  { "ta", 36, 0, 0, 1, 0 }, // http://qudt.org/vocab/unit#YearTropical
  { "u", 10, 1, 0, 0, 0 }, // http://qudt.org/vocab/unit#UnifiedAtomicMassUnit
  { "voxel", 23, 1, 0, 0, 0 }, // http://bitbucket.org/nxg/unity/ns/unit#Voxel
  { "yr", 37, 1, 0, 0, 1 }, // http://bitbucket.org/nxg/unity/ns/unit#JulianYear
};
struct { int map_start; int map_length; } unit_rep_per_syntax[] = {
  { 0, 66 }, /* fits */
  { 66, 49 }, /* ogip */
  { 115, 50 }, /* cds */
  { 165, 69 }, /* vounits */
};
/* Lookup between integers and UnitySyntax */
static UnitySyntax stxIndexes[] = {
  UNITY_SYNTAX_FITS,
  UNITY_SYNTAX_OGIP,
  UNITY_SYNTAX_CDS,
  UNITY_SYNTAX_VOUNITS,
};
static const int n_syntaxes = 4;


/*
 * A mapping, for each syntax, from unit number (index in the unit_defs array above)
 * to representation (index in the unit_reps array above)
 */
static int unit_to_representation[4][65] = {
  { 8, 59, 51, 18, 55, 1, 60, 39, 6, 45, 63, 36, 27, 20, -1, 49, 25, 35, 38, 37, 11, 28, 10, 64, 13, 26, 50, 17, 48, 40, -1, 47, 33, 24, 53, 56, 62, 65, 9, 21, 29, 14, 32, 2, 7, 46, 43, 30, 22, 12, 0, 42, 19, -1, 44, 61, 5, 3, 57, 41, 4, 16, 31, 58, 15, },
  { 72, -1, 107, 79, 109, 67, -1, 95, 70, 101, -1, -1, 87, 81, 69, 104, 85, 92, 94, 93, 75, -1, 74, 113, 77, 86, 105, -1, -1, 96, -1, 103, 91, -1, 108, 110, -1, 114, 73, 82, 88, 106, 90, 84, 71, 102, 99, -1, 83, 76, 66, 98, 80, -1, 100, 112, -1, -1, 111, 97, 68, -1, 89, -1, 78, },
  { 122, 161, 156, 131, 157, 117, 162, 146, 121, -1, -1, -1, 139, 133, -1, 154, 137, 143, 145, 144, 125, -1, 124, -1, 127, 138, 155, 130, 153, -1, 115, 152, -1, -1, -1, 158, -1, 164, 123, 134, -1, 128, 142, 118, -1, 151, 149, 140, 135, 126, 116, 148, 132, -1, 150, 163, 120, -1, 159, 147, 119, -1, 141, 160, 129, },
  { 174, 227, 219, 184, 223, 166, 228, 207, 172, 213, 231, -1, 195, 186, -1, 217, 192, 202, 206, 204, 177, 196, 176, 232, 179, 193, 218, 183, 216, 208, -1, 215, 201, 190, 221, 224, 230, 233, 175, 187, 197, 180, 200, 167, 173, 214, 211, 198, 188, 178, 165, 210, 185, 205, 212, 229, 171, 169, 225, 209, 170, 182, 199, 226, 181, },
};

static int unit_rep_compare(const void* key, const void* test)
{
    return strcmp((char*)key, ((UnitRep*)test)->symbol);
}

static int uu_syntax_to_integer(UnitySyntax syntax)
{
    int syntaxIdx;
    for (syntaxIdx = 0; syntaxIdx < n_syntaxes; syntaxIdx++) {
        if (stxIndexes[syntaxIdx] == syntax)
            break;
    }
    // if we haven't found a syntaxIdx, that's a programming error -- things are out of sync
    assert(syntaxIdx < n_syntaxes);
    return syntaxIdx;
}

/**
 * Retrieves a unit definition.  Returns NULL if the abbreviation is
 * not recognised in the indicated syntax (or if the syntax is invalid)
 * @param abbrev a unit abbreviation, for example "m" for "metre"
 * @param syntax one of the UNITY_SYNTAX_* constants
 * @return a pointer to a the unit definition which this abbreviation corresponds to
 */
const UnitDef* unity_get_unitdef_from_string(const char* abbrev, UnitySyntax syntax) 
{
    UnitRep *map;
    UnitRep *one_unit_rep;
    int maplen;
    int rep_index;
    int syntaxIdx = uu_syntax_to_integer(syntax);
    
    map = &unit_reps[unit_rep_per_syntax[syntaxIdx].map_start];
    maplen = unit_rep_per_syntax[syntaxIdx].map_length;
    
    one_unit_rep = (UnitRep*)bsearch((void*)abbrev,
                                     (void*)map, maplen, sizeof(UnitRep),
                                     &unit_rep_compare);
    if (one_unit_rep != NULL) {
        rep_index = one_unit_rep->_unit_index;
        return &unit_defs[rep_index];
    } else {
        return NULL;
    }
}

// Given a unit definition, find its representation in the given syntax
UnitRep* u_get_unit_representation(const UnitDef* ud, const UnitySyntax syntax)
{
    int unit_rep_index;
    int syntaxIdx = uu_syntax_to_integer(syntax);
    
    if (ud == NULL) {
        // this unit doesn't have a base_unit_def -- it wasn't recognised at parse time
        return NULL;            /* JUMP OUT */
    }
    assert(ud->_idx >= 0 && ud->_idx <unit_defs_length);

    unit_rep_index = unit_to_representation[syntaxIdx][ud->_idx];
    if (unit_rep_index < 0) {
        return NULL;
    } else {
        return &unit_reps[unit_rep_index];
    }
}

// Given a unit definition, find its representation in _any_ syntax.
// Since there are no units which are not represented in at least one
// syntax, this will always return non-NULL.
UnitRep* u_get_unit_representation_any(const UnitDef* ud)
{
    int i;
    UnitRep* rval = NULL;

    for (i=0; i<n_syntaxes; i++) {
        rval = u_get_unit_representation(ud, stxIndexes[i]);
        if (rval != NULL)
            break;
    }
    assert(rval != NULL);
    return rval;
}

/**
 * Looks up the name of the syntax with the given index.  Thus, this
 * is the inverse of {@link #unity_identify_parser}.
 * @param syntax one of the constants UNITY_SYNTAX_FITS, ...
 * @returns a string name for the syntax, or NULL if this is an unrecognised syntax
 */
const char* unity_get_syntax_name(const UnitySyntax syntax) 
{
    int syntaxIdx = uu_syntax_to_integer(syntax);
    return known_syntaxes[syntaxIdx];
}

/**
 * Returns the name of this unit, as a URI.  These unit definitions
 * follow the <a href='http://qudt.org'>QUDT</a> framework, though
 * they are not restricted to the units described there.  
 *
 * <p>This framework also supports the definition of unit kinds and
 * dimensions.
 * @returns a URI as a string
 */
const char* unity_get_unit_uri(const UnitDef* d)
{
    return (d == NULL ? NULL : d->uri);
}
/**
 * Returns the name of the unit.  This is a human-readable name such
 * as 'Metre' or 'Julian year', not the abbreviation 'm'
 */
const char* unity_get_unit_name(const UnitDef* d)
{
    return (d == NULL ? NULL : d->name);
}
/**
 * Returns the type of the unit, as a URI naming the 'kind' of thing
 * this measures.  This indicates 'Length' or 'Capacitance'.
 */
const char* unity_get_unit_type(const UnitDef* d)
{
    return (d == NULL ? NULL : d->type);
}
/**
 * Returns the dimensions of the unit
 *
 * <p>A dimensions string consists of a sequence of capital letter
 * dimensions, and powers, for example "M L2T-2" for the
 * dimensions of "kg m2 s-2".
 *
 * <p>The known dimensions are
 * <table>
 * <tr><th>Symbol<th>Name<th>SI base unit
 * <tr><td>U<td>Dimensionless<td>Unity
 * <tr><td>L<td>Length<td>Metre
 * <tr><td>M<td>Mass<td>Kilogramme
 * <tr><td>T<td>Time<td>Second
 * <tr><td>I<td>Electric current<td>Amp√®re
 * <tr><td>Œò<td>Thermodynamic temperature<td>Kelvin
 * <tr><td>N<td>Amount of substance<td>Mole
 * <tr><td>J<td>Luminous intensity<td>Candela
 * </table>
 */
const char* unity_get_unit_dimension(const UnitDef* d)
{
    return (d == NULL ? NULL : d->dimension);
}
/**
 * Returns a description of the unit.  This may be NULL if there is
 * nothing more to be said beyond the unit name.
 */
const char* unity_get_unit_description(const UnitDef* d)
{
    return (d == NULL ? NULL : d->description);
}
/**
 * A LaTeX version of the unit symbol, if there is one defined.
 */
const char* unity_get_unit_latex_form(const UnitDef* d)
{
    return (d == NULL ? NULL : d->latex_form);
}
