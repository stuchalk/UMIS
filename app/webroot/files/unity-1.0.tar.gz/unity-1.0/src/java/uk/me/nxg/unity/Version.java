package uk.me.nxg.unity;

/**
 * Manage version information
 */
public class Version {
    private static final String versionString = "unity 1.0, 2014 May 13";
    private static final int versionNumber = 1000000;

    private Version() {
        // constructor is protected on purpuse
    }

    /**
     * Indicate the package version, as a printable string giving the package name and version
     */
    public static String versionString() {
        return versionString;
    }

    /**
     * Indicate the package version, as an integer.
     * The number returned is major-version * 1e6 + minor-version * 1e3 + release.
     */
    public static int versionInteger() {
        return versionNumber;
    }
}
