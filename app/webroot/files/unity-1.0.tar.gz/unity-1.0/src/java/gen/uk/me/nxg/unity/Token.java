package uk.me.nxg.unity;
/** Token constants for the unit grammars. */
class Token {
  static final short SIGNED_INTEGER = Parser_fits.SIGNED_INTEGER;
  static final short UNSIGNED_INTEGER = Parser_fits.UNSIGNED_INTEGER;
  static final short FLOAT = Parser_fits.FLOAT;
  static final short STRING = Parser_fits.STRING;
  static final short QUOTED_STRING = Parser_fits.QUOTED_STRING;
  static final short VOUFLOAT = Parser_fits.VOUFLOAT;
  static final short CDSFLOAT = Parser_fits.CDSFLOAT;
  static final short WHITESPACE = Parser_fits.WHITESPACE;
  static final short STARSTAR = Parser_fits.STARSTAR;
  static final short CARET = Parser_fits.CARET;
  static final short DIVISION = Parser_fits.DIVISION;
  static final short DOT = Parser_fits.DOT;
  static final short STAR = Parser_fits.STAR;
  static final short PERCENT = Parser_fits.PERCENT;
  static final short OPEN_P = Parser_fits.OPEN_P;
  static final short CLOSE_P = Parser_fits.CLOSE_P;
  static final short OPEN_SQ = Parser_fits.OPEN_SQ;
  static final short CLOSE_SQ = Parser_fits.CLOSE_SQ;
  static final short LIT10 = Parser_fits.LIT10;
  private static java.util.Map<Integer,String> m = new java.util.HashMap<Integer,String>();
  static {
    m.put(Integer.valueOf(SIGNED_INTEGER), "SIGNED_INTEGER");
    m.put(Integer.valueOf(UNSIGNED_INTEGER), "UNSIGNED_INTEGER");
    m.put(Integer.valueOf(FLOAT), "FLOAT");
    m.put(Integer.valueOf(STRING), "STRING");
    m.put(Integer.valueOf(QUOTED_STRING), "QUOTED_STRING");
    m.put(Integer.valueOf(VOUFLOAT), "VOUFLOAT");
    m.put(Integer.valueOf(CDSFLOAT), "CDSFLOAT");
    m.put(Integer.valueOf(WHITESPACE), "WHITESPACE");
    m.put(Integer.valueOf(STARSTAR), "STARSTAR");
    m.put(Integer.valueOf(CARET), "CARET");
    m.put(Integer.valueOf(DIVISION), "DIVISION");
    m.put(Integer.valueOf(DOT), "DOT");
    m.put(Integer.valueOf(STAR), "STAR");
    m.put(Integer.valueOf(PERCENT), "PERCENT");
    m.put(Integer.valueOf(OPEN_P), "OPEN_P");
    m.put(Integer.valueOf(CLOSE_P), "CLOSE_P");
    m.put(Integer.valueOf(OPEN_SQ), "OPEN_SQ");
    m.put(Integer.valueOf(CLOSE_SQ), "CLOSE_SQ");
    m.put(Integer.valueOf(LIT10), "LIT10");
  }
  public static String lookup(int i) { return m.get(Integer.valueOf(i)); }
}
