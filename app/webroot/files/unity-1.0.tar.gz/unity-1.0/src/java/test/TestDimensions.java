import uk.me.nxg.unity.*;

import org.junit.Test;
import org.junit.Before;
import static org.junit.Assert.*;

public class TestDimensions {

    private static Dimensions d1;
    private static Dimensions d2;
    private static Dimensions d3;

    static {
        try {
            d1 = Dimensions.parse("L^-1 M-0.5 T^3 Θ "); // includes theta
            d2 = Dimensions.parse(" L  .+1 M T^*-2 "); // lots of space and other junk
            d3 = Dimensions.parse("L2MT2I"); // trailing letter (ie no following number)
        } catch (UnitParserException e) {
            System.err.println("Can't initialise!: " + e);
        }
    }
    // @Before public void setUp() {
    //     d1 = Dimensions.parse("L^-1 M-0.5 T^3 Θ "); // includes theta
    //     d2 = Dimensions.parse(" L  .+1 M T^*-2 "); // lots of space and other junk
    //     d3 = Dimensions.parse("L2MT2I"); // trailing letter (ie no following number)
    // }

    @Test public void testSimpleParse() throws Exception {
        float f1[] = { 0, -1, (float)-0.5,  3,  0, 1, 0, 0 };
        float f2[] = { 0,  1,         1,   -2,  0, 0, 0, 0 };
        float f3[] = { 0,  2,         1,    2,  1, 0, 0, 0 };
        assertArrayEquals("parse1", f1, d1.exponents(), (float)0.0);
        assertArrayEquals("parse2", f2, d2.exponents(), (float)0.0);
        assertArrayEquals("parse3", f3, d3.exponents(), (float)0.0);
    }

    @Test public void testMultiplication2() throws Exception {
        Dimensions d12 = d1.multiply(d2);
        float f[] = { 0,  0, (float)+0.5, 1, 0, 1, 0, 0 };
        assertArrayEquals("multiply2", f, d12.exponents(), (float)0.0);
    }

    @Test public void testMultiplicationMany() throws Exception {
        java.util.List<Dimensions> l = new java.util.ArrayList<Dimensions>();
        l.add(d1);
        l.add(d2);
        l.add(d3);

        Dimensions dn = Dimensions.multiply(l);
        float f[] = { 0,  2, (float)+1.5, 3, 1, 1, 0, 0 };

        assertArrayEquals("multiplySeveral", f, dn.exponents(), (float)0.0);
    }

    @Test public void testMultiplicationWithNull() throws Exception {
        java.util.List<Dimensions> l = new java.util.ArrayList<Dimensions>();
        l.add(d1);
        l.add(null);
        l.add(d3);

        // the following shouldn't fail, but should return null without error
        assertNull(Dimensions.multiply(l));
    }

    @Test public void testURLs() throws Exception {
        String base = "http://qudt.org/vocab/dimension#Dimension_SI_";
        
        assertEquals("URI1", base+"L-1M-0.5T3Θ", d1.getURI());
        assertEquals("URI2", base+"LMT-2", d2.getURI());
        assertEquals("URI3", base+"L2MT2I", d3.getURI());
    }

    @Test(expected=UnitParserException.class) public void testFails1() throws Exception {
        Dimensions.parse("L1 1"); // number without preceding letter
    }
    @Test(expected=UnitParserException.class) public void testFails2() throws Exception {
        Dimensions.parse("L1A1"); // bad uppercase letter
    }
    @Test(expected=UnitParserException.class) public void testFails3() throws Exception {
        Dimensions.parse("l1"); // lowercase letter
    }

    public static void main(String args[]) {
        org.junit.runner.JUnitCore.main("TestDimensions");
    }
}


    
