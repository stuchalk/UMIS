import org.junit.runner.JUnitCore;

public class RunTests {
    public static void main(String[] args) {
        JUnitCore.main(args);
    }
}
